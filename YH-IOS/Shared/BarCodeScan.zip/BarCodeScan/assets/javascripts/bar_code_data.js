(function(){
  window.BarCodeDataUtils = {
    xAxis: function() {
      var data = [], date = new Date(), month, dateInt;
      for(var i = 1, len = 15; i <= len; i ++) {
          month = date.getMonth() + 1;
          data.push(month + "/" + date.getDate());
          dateInt = date.valueOf() - 24 * 60 * 60 * 1000 * i;
          date.setTime(dateInt);
      }
      return data.reverse();
    }
  };

  window.BarCodeData = {
      chart: {
        title: '测试数据',
        series: [{
          "name": "销售金额",
          "type": "line",
          "data": [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
        }],
        xAxis: BarCodeDataUtils.xAxis()
      },
      tabs: [
        {
            title: "概况",
            table: {
                length: 2,
                0: ["标题 1", "标题 2", "标题 3"],
                1: ["行 1 数据 1", "行 1 数据 2", "行 3 数据 3"],
                2: ["行 2 数据 1", "行 2 数据 2", "行 3 数据 3"]
            }
        },
        {
            title: "同区情况",
            table: {
                length: 0,
                0: ["标题一", "标题二", "标题三"]
            }
        }
    ],
    timestamp: '16/10/18 15:40'
  };
}).call(this);
