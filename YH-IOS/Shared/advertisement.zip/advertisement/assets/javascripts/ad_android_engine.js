/**
 * @name ad engine
 * @version 0.0.1
 * @requires jQuery v1.2.3+
 * @license MIT License - http://www.opensource.org/licenses/mit-license.php
 *
 */
(function(){
  String.prototype.trim=function() {
    return this.replace(/(^\s*)|(\s*$)/g,'');
  }
  window.onerror = function(e) {
    if(window.AndroidJSBridge && window.AndroidJSBridge.jsException) {
      window.AndroidJSBridge.jsException(e);
    }
    else {
      console.log(typeof(e));
      console.log(e);
    }
  }
  window.MobileBridge = {
    htmlError: function(message) {
      if(typeof(window.AndroidJSBridge.htmlError) === "function") {
        window.AndroidJSBridge.htmlError(message);
      }
      console.log(message);
    },
    adLink: function(openType, openLink) {
      if(typeof(window.AndroidJSBridge.adLink) === "function") {
        window.AndroidJSBridge.adLink(openType, openLink);
      }
      else {
        MobileBridge.htmlError("window.AndroidJSBridge.adLink(openType, openLink) not found!");
      }
    }
  }
}).call(this);