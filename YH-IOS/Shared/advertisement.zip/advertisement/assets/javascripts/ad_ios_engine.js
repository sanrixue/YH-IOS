/**
 * @name ad engine
 * @version 0.0.1
 * @requires jQuery v1.2.3+
 * @license MIT License - http://www.opensource.org/licenses/mit-license.php
 *
 */
(function(){
    window.onerror = function(e) {
     if(MobileBridge.connectWebViewJavascriptBridge) {
        MobileBridge.connectWebViewJavascriptBridge(function(bridge){
          bridge.callHandler('jsException', {'ex': e}, function(response) {});
        })
      } else {
        console.log(typeof(e));
        console.log(e);
      }
    }
    window.MobileBridge = {
      connectWebViewJavascriptBridge: function(callback) {
        if(window.WebViewJavascriptBridge) {
          callback(WebViewJavascriptBridge)
        }
        else {
          document.addEventListener('WebViewJavascriptBridgeReady', function() {
            callback(WebViewJavascriptBridge)
          }, false)
        }
      },
      adLink: function(openType, openLink) {
        MobileBridge.connectWebViewJavascriptBridge(function(bridge){
          bridge.callHandler('adLink', {'openType': openType, 'openLink': openLink}, function(response) {
          });
        })
      }
    }
}).call(this)