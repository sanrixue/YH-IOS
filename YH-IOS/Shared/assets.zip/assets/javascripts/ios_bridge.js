(function(){
  String.prototype.trim=function() {
    return this.replace(/(^\s*)|(\s*$)/g,'');
  }

  window.IOSBridge = {
    connectWebViewJavascriptBridge: function(callback) {
      if(window.WebViewJavascriptBridge) {
        callback(WebViewJavascriptBridge)
      }
      else {
        document.addEventListener('WebViewJavascriptBridgeReady', function() {
          callback(WebViewJavascriptBridge)
        }, false)
      }
    },
    pageLink: function(bannerName, link, objectId) {
      //alert(bannerName)

      IOSBridge.connectWebViewJavascriptBridge(function(bridge){
        bridge.callHandler('iosCallback', {'bannerName': bannerName, 'link': link, 'objectID': objectId}, function(response) {
        });
      })
    },
    writeComment: function() {
      var content = document.getElementById("content").value.trim();

      if(content.length > 0) {
        IOSBridge.connectWebViewJavascriptBridge(function(bridge){
          bridge.callHandler('writeComment', {'content': content}, function(response) {
          });
        })
      }
      else {
        alert("请输入评论内容");
      }
    }
  }
}).call(this);