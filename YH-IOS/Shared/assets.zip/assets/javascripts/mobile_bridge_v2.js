MOBILEBRIDGEVERSION = '2.0.1'

String.prototype.trim = function() {
  return this.replace(/(^\s*)|(\s*$)/g,'');
}
window.onerror = function(e) {
  if(window.AndroidJSBridge && window.AndroidJSBridge.jsException) {
    window.AndroidJSBridge.jsException(e);
  }
  else {
    console.log(typeof(e));
    console.log(e);
  }
}

window.MBV2WithinAndroid = {
  platform: 'android',
  version: MOBILEBRIDGEVERSION,
  version: function() {
    return window.MBV2WithinAndroid.platform + ' ' + MOBILEBRIDGEVERSION;
  },
  htmlError: function(message) {
    if(window.AndroidJSBridge && typeof(window.AndroidJSBridge.htmlError) === "function") {
      window.AndroidJSBridge.htmlError(message);
    }
  },
  pageLink: function(bannerName, link, objectId) {
    window.AndroidJSBridge.pageLink(bannerName, link, objectId);
  },
  writeComment: function() {
    var content = document.getElementById("content").value.trim();
    if(content.length) {
      window.AndroidJSBridge.writeComment(content);
    } else {
      alert("请输入评论内容");
    }
  },
  storeTabIndex: function(pageName, tabIndex) {
    if(!window.AndroidJSBridge || typeof(window.AndroidJSBridge.storeTabIndex) !== "function") {
      window.MBV2WithinAndroid.htmlError("window.AndroidJSBridge.storeTabIndex(pageName, tabIndex) not found!");
      return;
    }
    window.AndroidJSBridge.storeTabIndex(pageName, tabIndex);
  },
  restoreTabIndex: function(pageName) {
    if(!window.AndroidJSBridge || typeof(window.AndroidJSBridge.restoreTabIndex) !== "function") {
      widnow.MBV2WithinAndroid.htmlError("window.AndroidJSBridge.restoreTabIndex(pageName) not found!");
      return;
    }
    $(".tab-part").addClass("hidden");
    var tabIndex = window.AndroidJSBridge.restoreTabIndex(pageName),
        klass = ".tab-part-" + tabIndex;
    $(klass).removeClass("hidden");
    $(".day-container").removeClass("highlight");
    $(".day-container").each(function() {
      var eIndex = parseInt($(this).data("index"));
      if(eIndex === tabIndex) { $(this).addClass("highlight"); }
    })
  },
  resetPassword: function(oldPassword, newPassword) {
    window.AndroidJSBridge.resetPassword(oldPassword, newPassword);
  },
  forgetPassword: function(usernum, mobile) {
    window.AndroidJSBridge.forgetPassword(usernum, mobile);
  },
  setSearchItems: function(items) {
    if(window.AndroidJSBridge && typeof(window.AndroidJSBridge.reportSearchItems) === "function") {
      window.AndroidJSBridge.reportSearchItems(JSON.stringify(items));
    } else {
      window.MBV2WithinAndroid.htmlError("window.AndroidJSBridge.reportSearchItems(itemsString) not found!");
    }
  },
  getReportSelectedItem: function(templateCallback) {
    var selectedItem = null;
    if(window.AndroidJSBridge && typeof(window.AndroidJSBridge.reportSelectedItem) === "function") {
      selectedItem = window.AndroidJSBridge.reportSelectedItem();
    } else {
      window.MBV2WithinAndroid.htmlError("window.AndroidJSBridge.reportSelectedItem() not found!");
    }
    templateCallback(selectedItem);
  },
  setDashboardDataCount: function(tabType, dataCount) {
    if(window.AndroidJSBridge && typeof(window.AndroidJSBridge.setDashboardDataCount) === "function") {
      window.AndroidJSBridge.setDashboardDataCount(tabType, dataCount);
    } else {
      window.MBV2WithinAndroid.htmlError("window.AndroidJSBridge.setDashboardDataCount(tabType, dataCount) not found!");
    }
  },
  hideAd: function() {
    if(window.AndroidJSBridge && typeof(window.AndroidJSBridge.hideAd) === "function") {
      window.AndroidJSBridge.hideAd();
    } else {
      window.MBV2WithinAndroid.htmlError("window.AndroidJSBridge.hideAd() not found!");
    }
  }
}


window.MBV2WithinIOS = {
  platform: 'ios',
  version: MOBILEBRIDGEVERSION,
  version: function() {
    return window.MBV2WithinIOS.platform + ' ' + MOBILEBRIDGEVERSION;
  },
  connectWebViewJavascriptBridge: function(callback) {
    if(window.WebViewJavascriptBridge) {
      callback(WebViewJavascriptBridge);
    } else {
      document.addEventListener('WebViewJavascriptBridgeReady', function() { callback(WebViewJavascriptBridge) }, false);
    }
  },
  pageLink: function(bannerName, link, objectId) {
    window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
      bridge.callHandler('iosCallback', {'bannerName': bannerName, 'link': link, 'objectID': objectId}, function(response) {});
    })
  },
  writeComment: function() {
    var content = document.getElementById("content").value.trim();

    if(content.length > 0) {
      window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
        bridge.callHandler('writeComment', {'content': content}, function(response) {});
      })
    } else {
      alert("请输入评论内容");
    }
  },
  storeTabIndex: function(pageName, tabIndex) {
    window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
      bridge.callHandler('pageTabIndex', {'action': 'store', 'pageName': pageName, 'tabIndex': tabIndex}, function(response) {});
    })
  },
  restoreTabIndex: function(pageName) {
    $(".tab-part").addClass("hidden");
    window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
      bridge.init(function(message, responseCallback) {
      })
      bridge.callHandler('pageTabIndex', {'action': 'restore', 'pageName': pageName}, function(response) {
        var tabIndex = response,
            klass = ".tab-part-" + tabIndex;
        $(klass).removeClass("hidden");

        $(".day-container").removeClass("highlight");
        $(".day-container").each(function() {
          var eIndex = parseInt($(this).data("index")) ;
          if(eIndex === tabIndex) {
            $(this).addClass("highlight");
          }
        })
      });
    })
  },
  resetPassword: function(oldPassword, newPassword) {
    window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
      bridge.init(function(message, responseCallback) {})
      bridge.callHandler('ResetPassword', {'oldPassword': oldPassword, 'newPassword': newPassword}, function(response) {});
    })
  },
  forgetPassword: function(usernum, mobile) {
    window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
      bridge.init(function(message, responseCallback) {})
      bridge.callHandler('ForgetPassword', {'usernum': usernum, 'mobile': mobile}, function(response) {});
    })
  },
  setSearchItems: function(items) {
    window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
      bridge.init(function(message, responseCallback) {})
      bridge.callHandler('searchItems', {'items': items}, function(response) {});
    })
  },
  getReportSelectedItem: function(templateCallback) {
    window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
      bridge.callHandler('selectedItem', {}, function(response) {
        templateCallback(response);
      });
    })
  },
  setDashboardDataCount: function(tabType, dataCount) {
    window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
      bridge.callHandler('dashboardDataCount', {'tabType': tabType, 'dataCount': dataCount}, function(response) {});
    })
  },
  hideAd: function() {
    window.MBV2WithinIOS.connectWebViewJavascriptBridge(function(bridge) {
      bridge.callHandler('hideAd', {}, function(response) {});
    })
  }
}
window.MBV2 = {
  platform: 'pc',
  version: MOBILEBRIDGEVERSION,
  version: function() {
    return window.MBV2.platform + ' ' + MOBILEBRIDGEVERSION;
  },
  warning: function(action) {
    console.log("pc no atcion - " + action);
  },
  alert: function(message) {
    alert(message);
  },
  pageLink: function(bannerName, link, objectId) {
    window.location.href = link;
  },
  writeComment: function() {
    window.MBV2.warning("writeComment");
  },
  storeTabIndex: function(pageName, tabIndex) {
    window.MBV2.warning("storeTabIndex");
  },
  restoreTabIndex: function(pageName) {
    return 0;
  },
  setSearchItems: function(items) {
    window.MBV2.warning("setSearchItems");
  },
  reportSelectedItem: function() {
    return null;
  },
  setDashboardDataCount: function(tabType, dataCount) {
    window.MBV2.warning("setDashboardDataCount");
  },
  hideAd: function() {
    window.MBV2.warning("hideAd");
  },
  resetPassword: function(oldPassword, newPassword) {
    window.MBV2.warning("resetPassword");
  },
  forgetPassword: function(usernum, mobile) {
    window.MBV2.warning("forgetPassword");
  }
}

var userAgent = navigator.userAgent,
    isAndroid = userAgent.indexOf('Android') > -1 || userAgent.indexOf('Adr') > -1,
    isiOS = !!userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
if(isiOS) {
  window.MBV2 = window.MBV2WithinIOS;
} else if(isAndroid) {
  window.MBV2 = window.MBV2WithinAndroid;
}
console.log(window.MBV2.version());
