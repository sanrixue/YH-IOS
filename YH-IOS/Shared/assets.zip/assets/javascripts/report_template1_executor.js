(function(){
  window.onload = function() {
    
    ReportTemplate1.generateTemplates(TemplateData.templates);

    $('a.table-more').click(function(e){
      e.preventDefault()
      $this = $(this);
      $currentRow = $this.closest('tr');
      $currentRow.nextUntil('tr[class!=more-items]').toggle();
      $this.toggleClass('table-more-closed');
    });

    $('a.day-container').click(function(el) {
      el.preventDefault();

      $(".day-container").removeClass("highlight");
      $(this).addClass("highlight");

      var klass = ".tab-part-" + $(this).data("index");
      $(".tab-part").addClass("hidden");
      $(klass).removeClass("hidden");
    });
  }
}).call(this);