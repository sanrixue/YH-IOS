/* jslint plusplus: true */
/* global
     $:false, 
     ReportTemplate1:false,
     echarts:false
*/

(function(){

  "use strict";

  window.ReportTemplate1 = {
    modal: function(ctl) {
        var date1 = new Date().getTime(),
            $modal = $("#ReportTemplate1Modal");

        $modal.modal("show");
        $modal.find(".modal-title").html($(ctl).data("title"));
        $modal.find(".modal-body").html($(ctl).data("content"));

        var date2 = new Date().getTime(),
            dif = date2 - date1;
        console.log("duration: " + dif);
    },
    outerApi: function(ctl) {
      var $modal = $("#ReportTemplate1Modal"),
          url = $(ctl).data("url"),
          split = url.indexOf("?") > 0 ? "&" : "?";

      url = url + split + $(ctl).data("params");

      $modal.modal("show");
      $modal.find(".modal-title").html($(ctl).data("title"));

      $.ajax({
        type: "GET",
        url: url, 
        success:function(result) {
          try {
              var json = JSON.parse(result),
                  regPhone1 = /^1\d{10}$/,
                  regPhone2 = /^0\d{2,3}-?\d{7,8}$/,
                  regEmail = /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/,
                  table = "<table class='table'><tbody>";

              for(var key in json) {
                var value = json[key];
                if(regPhone1.test(value) || regPhone2.test(value)) {
                  value = "<a class='sms' href='tel:" + value + "'>" + value + "</a>&nbsp;&nbsp;&nbsp;&nbsp;" +
                          "<a class='tel' href='sms:" + value + "'> 短信 </a>";
                }
                else if(regEmail.test(value)) {
                  value = "<a class='mail' href='mailto:'" + value + "'>" + value + "</a>";
                }
                table = table + "<tr><td>" + key + "</td><td>" +value + "</td></tr>";
              }
              table = table + "</tbody></table>";

              $modal.find(".modal-body").html(table);
          } catch (e) {
              console.log(e);
              $modal.find(".modal-body").html(result);
          }
        },
        error:function(XMLHttpRequest, textStatus, errorThrown) {
              $modal.find(".modal-body").html("GET " + url + "<br>状态:" + textStatus + "<br>报错:" + errorThrown);
        }
      });
    },
    checkArrayForChart: function(array) {
        for(var index = 0, len = array.length; index < len; index ++) {
          if(array[index] === null) { 
            array[index] = undefined; 
          }
        }
        return array;
    },
    generateTable: function(heads, rows, outerApi) {
      var tmpArray = [],
          isOuterAapi = (typeof(outerApi) !== 'undefined'),
          htmlString;

      for(var index = 0, len = heads.length; index < len; index ++) {
        tmpArray.push(heads[index]);
      }
      htmlString = "<thead><th>" + tmpArray.join("</th><th>") + "</th></thead>";

      // clear array
      tmpArray.length = 0;
      for(var rowIndex = 0, rowLen = rows.length; rowIndex < rowLen; rowIndex ++) {
        var row = rows[rowIndex],
            isRoot = (row[0] === 1 || row[0] === "1"),
            rowString;

        for(var dataIndex = 1, dataLen = row.length; dataIndex < dataLen; dataIndex ++) {
          var data = row[dataIndex];

          if(isOuterAapi && !isRoot && outerApi.target === dataIndex) {
            data = "<a href='javascript:void(0);' onclick='ReportTemplate1.outerApi(this);' " +
                   "data-title='" + data + "' " +
                   "data-url='" + outerApi.url + "' " +
                   "data-params='" + outerApi.data[rowIndex] + "'>" + data + 
                   "</a>";
          }

          if(dataIndex === 1) {
            rowString = (isRoot ? "\
              <tr>\
                <td>\
                  <a href='#' class='table-more table-more-closed'>" 
                    + data + 
                  "</a>\
                </td>"
                :
              "<tr class='more-items' style='display:none'> \
                <td>&nbsp;&nbsp;&nbsp;" 
                  + data + 
                "</td>");
          }
          else {
            rowString += "<td>" + data + "</td>";
          }
        }
        rowString += "</tr>";

        tmpArray.push(rowString);
      }
      htmlString += "<tbody>" + tmpArray.join("") + "</tbody>";

      return htmlString;
    },
    generateTabs: function(tabs) {
      var tabIndex = (new Date()).valueOf(), 
          tmpArray = [],
          htmlString,
          i, len;

      for(i = 0, len = tabs.length; i < len; i ++) {
        tmpArray.push("<li class='" + (i === 0 ? "active" : "") + "'>\
                        <a data-toggle='tab' href='#tab_" + tabIndex + "_" + i + "'>" + tabs[i].title + "</a>\
                      </li>");
      }
      htmlString = "<ul class='nav nav-tabs'>" + 
                     tmpArray.join("") + 
                   "</ul>";

      // clear array
      tmpArray.length = 0;
      for(i = 0, len = tabs.length; i < len; i ++) {
        tmpArray.push("<div id='tab_" + tabIndex + "_" + i + "' class='tab-pane animated fadeInUp " + (i === 0 ? "active" : "") + "'>\
                        <div class='row'  style='margin-left:0px;margin-right:0px'>\
                          <div class='col-lg-12' style='padding-left:0px;padding-right:0px'>\
                            <table class='table table-striped table-bordered table-hover'>"
                              + ReportTemplate1.generateTable(tabs[i].table.head, tabs[i].table.data, tabs[i].outer_api) +
                            "</table>\
                          </div>\
                        </div>\
                      </div>");
      }
      htmlString += "<div class='tab-content tabs-flat no-padding'>" +
                      tmpArray.join("") + 
                    "</div>";

      return htmlString;
    },

    // after require echart.js
    generateChart: function(option) {
      for(var i = 0, len = option.series.length; i < len; i ++) {
          option.series[i].data = ReportTemplate1.checkArrayForChart(option.series[i].data);
      }

      return {
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            x: 'center',
            y: 'top',
            data: option.legend
        },
        toolbox: {
            show : false,
            x: 'right',
            y: 'top',
            feature : {
                mark : {show: true},
                dataView : {show: true, readOnly: false},
                magicType : {show: true, type: ['line', 'bar']},
                restore : {show: true},
                saveAsImage : {show: false}
            }
        },
        calculable : true,
        grid: {y: 17, y2:20, x2:2, x:40},
        xAxis : [
            {
                type : 'category',
                boundaryGap : true,
                data : option.xAxis
            }
        ],
        yAxis : option.yAxis,
        series : option.series
      }; 
    },
    generateTemplate: function(index, template) {
      return "\
      <div class='row tab-part tab-part-" + index + "' style='margin-left:0px;margin-right:0px'>\
          <div class='col-lg-12 col-sm-12 col-xs-12' style='padding-left:0px;padding-right:0px'>\
            <div class='databox radius-bordered bg-white databox-shadowed' style='height:100%;'>\
              <div class='databox-row'>\
                <div class='databox-cell cell-12 text-align-center bordered-right bordered-platinum'>\
                  \
                  <div class='databox-stat bg-gray radius-bordered' style='left:7px;right:initial;'>\
                    <div class='stat-text'>"
                      + template.banner.date + "\
                    </div>\
                  </div>\
                  <span class='databox-number lightcarbon'> " 
                    + template.banner.title + "\
                  </span>\
                  <span class='databox-number sonic-silver no-margin'>"
                    + template.banner.subtitle + "\
                  </span>\
                  \
                  <div class='databox-stat '>\
                    <div class='stat-text'>\
                      <a href='javascript:void(0);' style='color:#ccc!important;' onclick='ReportTemplate1.modal(this);' data-title='" + template.banner.title + "' data-content='" + template.banner.info + "'>" + "\
                        <span style='font-size:20px;' class='glyphicon glyphicon-info-sign'></span>\
                      </a>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
      </div>"
      + (typeof(template.is_show_chart) !== "undefined" && template.is_show_chart === true ? "\
      <div class='row tab-part tab-part-" + index + "'  style='margin-left:0px;margin-right:0px'>\
        <div class='widget'>\
          <div class='widget-body'>\
            <div class='row'>\
              <div class='col-sm-12'  style='padding-left:0px;padding-right:0px'>\
                <div id='template_chart_" + index + "' class='chart chart-lg'></div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>" : "") 
      + "\
      <div class='row tab-part tab-part-" + index + "'  style='margin-left:0px;margin-right:0px'>\
        <div class='col-xs-12'  style='padding-left:0px;padding-right:0px'>\
          <div class='dashboard-box'>\
            <div class='box-tabbs'>\
              <div class='tabbable'>"
                + ReportTemplate1.generateTabs(template.tabs) + "\
              </div>\
              \
            </div>\
          </div>\
        </div>\
      </div>";
    }, 
    generateTemplates: function(templates) {
      var tabNav = document.getElementById("tabNav"),
          tabContent = document.getElementById("tabContent"),
          colNum = parseInt(12 / templates.length),
          template,
          i, len;

      for(i = 0, len = templates.length; i < len; i ++) {
        template = templates[i];

        tabNav.innerHTML += "\
          <div class='col-lg-" + colNum + " col-md-" + colNum + " col-sm-" + colNum + " col-xs-" + colNum + "'>\
            <a class='day-container " + (i === 0 ? "highlight" : "") + "' data-index=" + i + ">\
              <div class='day'>" 
                + template.title + "\
              </div>\
            </a>\
          </div>";

        tabContent.innerHTML += ReportTemplate1.generateTemplate(i, template);
      }

      for(i = 0, len = templates.length; i < len; i ++) {
        template = templates[i];

        if(typeof(template.is_show_chart) !== "undefined" && template.is_show_chart === true) {
          var chart = echarts.init(document.getElementById("template_chart_" + i));
          chart.setTheme('macarons');
          chart.setOption(ReportTemplate1.generateChart(template.chart));
        }

        if(i !== 0) {
          $(".tab-part-"+i).addClass("hidden");
        }
      }

      var modalHtml = '\
        <div class="modal fade in" id="ReportTemplate1Modal">\
          <div class="modal-dialog">\
            <div class="modal-content">\
              <div class="modal-header">\
                <button aria-label="Close" class="close" data-dismiss="modal" type="button">\
                  <span aria-hidden="true"> ×</span>\
                </button>\
                <h4 class="modal-title">...</h4>\
              </div>\
              <div class="modal-body">\
              loading...\
              </div>\
            </div>\
          </div>\
        </div>';

      $(modalHtml).appendTo($("body"));
    }
  }

}).call(this)
